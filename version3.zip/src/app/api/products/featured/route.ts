import { NextResponse } from 'next/server';
import { Product } from '@/lib/types';

// Mock data
const featuredProducts: Product[] = [
  {
    id: 1,
    name: 'برنج طارم ممتاز',
    description: 'برنج طارم درجه یک با کیفیت عالی از شالیزارهای شمال',
    price: 480000,
    image: 'https://placehold.co/300x200/eef5bf/435938?text=برنج+طارم',
    stock: 50
  },
  {
    id: 2,
    name: 'برنج هاشمی اعلا',
    description: 'برنج هاشمی با دانه‌های بلند و عطر و طعم بی‌نظیر',
    price: 450000,
    image: 'https://placehold.co/300x200/eef5bf/435938?text=برنج+هاشمی',
    stock: 30
  },
  {
    id: 3,
    name: 'برنج دم سیاه',
    description: 'برنج دم سیاه با کیفیت مرغوب از مزارع گیلان',
    price: 520000,
    image: 'https://placehold.co/300x200/eef5bf/435938?text=برنج+دم+سیاه',
    stock: 20
  }
];

export async function GET() {
  return NextResponse.json(featuredProducts);
}
