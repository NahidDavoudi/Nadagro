import MovieGrid from '@/components/movies/MovieGrid';

export default function MoviesPage() {
  return <MovieGrid />;
}