import React from 'react';
import Image from 'next/image';

interface MovieCardProps {
  title: string;
  description: string;
  year: string;
  duration: string;
  imageUrl: string;
}

const MovieCard: React.FC<MovieCardProps> = ({ title, description, year, duration, imageUrl }) => {
  return (
    <div className="bg-white rounded-xl overflow-hidden shadow-lg transition-all duration-300 hover:shadow-xl hover:-translate-y-1">
      <div className="relative h-[280px] w-full bg-gray-100">
        <Image
          src={imageUrl}
          alt={title}
          fill
          className="object-cover"
          sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
        />
      </div>
      <div className="bg-blue-600 p-4 space-y-2">
        <h3 className="text-lg font-bold text-white text-right">{title}</h3>
        <p className="text-sm text-gray-100 text-right line-clamp-2">{description}</p>
        <div className="flex justify-between items-center pt-2 text-sm text-gray-200">
          <span>{duration}</span>
        <span>{year}</span>
        </div>
      </div>
    </div>
  );
};

const MovieGrid: React.FC = () => {
  const movies = [
    {
    title: "فیلم اول",
    description: "توضیحات کوتاه درباره فیلم اول که می‌تواند در دو خط نمایش داده شود",
    year: "۲۰۲۳",
    duration: "۹۰ دقیقه",
    imageUrl: "https://via.placeholder.com/300x400"
    },
    {
      title: "فیلم دوم",
      description: "توضیحات کوتاه درباره فیلم دوم که شامل جزئیات بیشتری است",
      year: "۲۰۲۳",
      duration: "۱۲۰ دقیقه",
      imageUrl: "https://via.placeholder.com/300x400"
    },
    {
      title: "فیلم سوم",
      description: "این فیلم یک داستان جذاب را روایت می‌کند که مخاطب را درگیر می‌کند",
      year: "۲۰۲۳",
      duration: "۱۰۵ دقیقه",
      imageUrl: "https://via.placeholder.com/300x400"
    },
    {
      title: "فیلم چهارم",
      description: "داستانی پر از هیجان و ماجراجویی که نباید از دست بدهید",
      year: "۲۰۲۳",
      duration: "۹۵ دقیقه",
      imageUrl: "https://via.placeholder.com/300x400"
    },
  ];

  return (
    <section className="min-h-screen bg-gray-900 text-white py-8">
      {/* Header Section */}
      <header className="container mx-auto px-4 mb-8">
        <div className="bg-blue-600 rounded-xl p-4 shadow-lg">
          <div className="flex justify-between items-center">
            <div className="flex space-x-4 rtl:space-x-reverse">
              <button className="px-4 py-2 bg-blue-700 text-white rounded-lg hover:bg-blue-800 transition-colors">
                فیلم
              </button>
              <button className="px-4 py-2 bg-blue-700 text-white rounded-lg hover:bg-blue-800 transition-colors">
                سریال
              </button>
            </div>
            <h2 className="text-xl font-bold">دسته‌بندی</h2>
          </div>
        </div>
      </header>

      {/* Content Section */}
      <div className="container mx-auto px-4">
        <div className="bg-blue-600/20 rounded-xl p-6">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {movies.map((movie, index) => (
              <MovieCard key={index} {...movie} />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default MovieGrid;