'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { ArrowRight } from 'react-feather';
import { useAuth } from '@/lib/hooks/useAuth';
import { Discount } from '@/lib/types';
import { formatPrice } from '@/lib/utils';

export default function ReferralsPage() {
  const router = useRouter();
  const { user, isLoading } = useAuth();
  
  const [referralCount, setReferralCount] = useState(0);
  const [discounts, setDiscounts] = useState<Discount[]>([]);
  const [isLoadingData, setIsLoadingData] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Redirect to login if not authenticated
  useEffect(() => {
    if (!isLoading && !user) {
      router.push('/auth');
    }
  }, [user, isLoading, router]);

  useEffect(() => {
    const fetchReferralData = async () => {
      if (!user) return;
      
      setIsLoadingData(true);
      try {
        // In a real app, this would be API calls
        // const profileResponse = await fetch('/api/profile');
        // const discountsResponse = await fetch('/api/discounts');
        
        // Mock data
        setReferralCount(3); // Mock: 3 referrals
        setDiscounts([
          {
            id: 1,
            user_id: user.id,
            amount: 25000,
            reason: 'پاداش معرفی کاربر جدید',
            created_at: '2023-12-15T10:30:00'
          },
          {
            id: 2,
            user_id: user.id,
            amount: 25000,
            reason: 'پاداش معرفی کاربر جدید',
            created_at: '2023-11-20T14:45:00'
          },
          {
            id: 3,
            user_id: user.id,
            amount: 25000,
            reason: 'پاداش معرفی کاربر جدید',
            created_at: '2023-10-05T09:15:00'
          }
        ]);
      } catch (err) {
        console.error('Error fetching referral data:', err);
        setError('خطا در دریافت اطلاعات');
      } finally {
        setIsLoadingData(false);
      }
    };

    fetchReferralData();
  }, [user]);

  if (isLoading || !user) {
    return <div className="p-4 text-center">در حال بارگذاری...</div>;
  }

  const totalBonus = discounts.reduce((sum, d) => sum + d.amount, 0);

  return (
    <div className="p-4">
      <div className="flex items-center mb-6">
        <Link href="/profile" className="ml-3 p-2 rounded-full hover:bg-gray-100">
          <ArrowRight className="w-6 h-6 text-text-primary" />
        </Link>
        <h2 className="text-xl font-bold text-text-primary">پاداش‌های من</h2>
      </div>
      
      {error ? (
        <p className="text-center text-red-500 p-4">{error}</p>
      ) : isLoadingData ? (
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="bg-gray-200 animate-pulse h-24 rounded-xl"></div>
            <div className="bg-gray-200 animate-pulse h-24 rounded-xl"></div>
          </div>
          <div className="space-y-3">
            {[1, 2, 3].map(i => (
              <div key={i} className="bg-gray-200 animate-pulse h-16 rounded-lg"></div>
            ))}
          </div>
        </div>
      ) : (
        <>
          <div id="referral-summary" className="grid grid-cols-2 gap-4 mb-6">
            <div className="bg-white p-4 rounded-xl shadow-md text-center">
              <p className="text-sm text-text-secondary">افراد دعوت شده</p>
              <p className="text-2xl font-bold text-blue">{referralCount}</p>
            </div>
            <div className="bg-white p-4 rounded-xl shadow-md text-center">
              <p className="text-sm text-text-secondary">مجموع پاداش</p>
              <p className="text-2xl font-bold text-green">
                {formatPrice(totalBonus)} <span className="text-sm">تومان</span>
              </p>
            </div>
          </div>
          
          <div>
            <h3 className="text-base font-semibold mb-3 text-text-primary px-2">تاریخچه پاداش‌ها</h3>
            <div className="space-y-3">
              {discounts.length > 0 ? (
                discounts.map(discount => (
                  <div key={discount.id} className="bg-white p-3 rounded-lg shadow-sm flex justify-between items-center">
                    <div>
                      <p className="font-semibold text-sm text-text-primary">{discount.reason}</p>
                      <p className="text-xs text-text-secondary">
                        {new Date(discount.created_at).toLocaleDateString('fa-IR')}
                      </p>
                    </div>
                    <p className="font-bold text-green">+{formatPrice(discount.amount)} تومان</p>
                  </div>
                ))
              ) : (
                <p className="text-center text-text-secondary p-4">هنوز پاداشی دریافت نکرده‌اید.</p>
              )}
            </div>
          </div>
        </>
      )}
    </div>
  );
}
