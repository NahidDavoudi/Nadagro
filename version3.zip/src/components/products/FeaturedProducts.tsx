'use client';

import React, { useState, useEffect } from 'react';
import ProductCard from './ProductCard';
import { Product } from '@/lib/types';

export default function FeaturedProducts() {
  const [products, setProducts] = useState<Product[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchProducts = async () => {
      try {
        // In a real app, this would fetch from an API
        const response = await fetch('/api/products/featured');
        
        if (!response.ok) {
          throw new Error('Failed to fetch featured products');
        }
        
        const data = await response.json();
        setProducts(data.slice(0, 3)); // Only show first 3 products
      } catch (err) {
        console.error('Error fetching featured products:', err);
        setError('خطا در بارگذاری محصولات');
        
        // For demo purposes, set some mock products
        setProducts([
          {
            id: 1,
            name: 'برنج طارم ممتاز',
            description: 'برنج طارم درجه یک با کیفیت عالی از شالیزارهای شمال',
            price: 480000,
            image: 'https://placehold.co/300x200/eef5bf/435938?text=برنج+طارم',
            stock: 50
          },
          {
            id: 2,
            name: 'برنج هاشمی اعلا',
            description: 'برنج هاشمی با دانه‌های بلند و عطر و طعم بی‌نظیر',
            price: 450000,
            image: 'https://placehold.co/300x200/eef5bf/435938?text=برنج+هاشمی',
            stock: 30
          },
          {
            id: 3,
            name: 'برنج دم سیاه',
            description: 'برنج دم سیاه با کیفیت مرغوب از مزارع گیلان',
            price: 520000,
            image: 'https://placehold.co/300x200/eef5bf/435938?text=برنج+دم+سیاه',
            stock: 20
          }
        ]);
      } finally {
        setIsLoading(false);
      }
    };

    fetchProducts();
  }, []);

  if (isLoading) {
    return (
      <div className="space-y-3">
        {[1, 2, 3].map(i => (
          <div key={i} className="bg-gray-200 animate-pulse h-24 rounded-xl"></div>
        ))}
      </div>
    );
  }

  if (error) {
    return <p className="text-center text-red-500 p-4">{error}</p>;
  }

  return (
    <div className="space-y-3">
      {products.map(product => (
        <ProductCard key={product.id} product={product} variant="list" />
      ))}
    </div>
  );
}
