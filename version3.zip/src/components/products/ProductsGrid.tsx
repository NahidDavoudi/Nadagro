'use client';

import React, { useState, useEffect } from 'react';
import ProductCard from './ProductCard';
import { Product } from '@/lib/types';

export default function ProductsGrid() {
  const [products, setProducts] = useState<Product[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchProducts = async () => {
      try {
        // In a real app, this would fetch from an API
        const response = await fetch('/api/products');
        
        if (!response.ok) {
          throw new Error('Failed to fetch products');
        }
        
        const data = await response.json();
        setProducts(data);
      } catch (err) {
        console.error('Error fetching products:', err);
        setError('خطا در بارگذاری محصولات');
        
        // For demo purposes, set some mock products
        setProducts([
          {
            id: 1,
            name: 'برنج طارم ممتاز',
            description: 'برنج طارم درجه یک با کیفیت عالی از شالیزارهای شمال',
            price: 480000,
            image: 'https://placehold.co/300x200/eef5bf/435938?text=برنج+طارم',
            stock: 50
          },
          {
            id: 2,
            name: 'برنج هاشمی اعلا',
            description: 'برنج هاشمی با دانه‌های بلند و عطر و طعم بی‌نظیر',
            price: 450000,
            image: 'https://placehold.co/300x200/eef5bf/435938?text=برنج+هاشمی',
            stock: 30
          },
          {
            id: 3,
            name: 'برنج دم سیاه',
            description: 'برنج دم سیاه با کیفیت مرغوب از مزارع گیلان',
            price: 520000,
            image: 'https://placehold.co/300x200/eef5bf/435938?text=برنج+دم+سیاه',
            stock: 20
          },
          {
            id: 4,
            name: 'برنج صدری',
            description: 'برنج صدری با عطر و طعم فوق‌العاده از مزارع مازندران',
            price: 460000,
            image: 'https://placehold.co/300x200/eef5bf/435938?text=برنج+صدری',
            stock: 40
          },
          {
            id: 5,
            name: 'برنج علی کاظمی',
            description: 'برنج علی کاظمی با کیفیت عالی و پخت عالی',
            price: 440000,
            image: 'https://placehold.co/300x200/eef5bf/435938?text=برنج+علی+کاظمی',
            stock: 25
          },
          {
            id: 6,
            name: 'برنج فجر',
            description: 'برنج فجر با دانه‌های متوسط و طعم مطلوب',
            price: 420000,
            image: 'https://placehold.co/300x200/eef5bf/435938?text=برنج+فجر',
            stock: 35
          }
        ]);
      } finally {
        setIsLoading(false);
      }
    };

    fetchProducts();
  }, []);

  if (isLoading) {
    return (
      <div className="grid grid-cols-2 gap-4">
        {[1, 2, 3, 4].map(i => (
          <div key={i} className="bg-gray-200 animate-pulse h-48 rounded-xl"></div>
        ))}
      </div>
    );
  }

  if (error) {
    return <p className="text-center text-red-500 p-4">{error}</p>;
  }

  return (
    <div className="grid grid-cols-2 gap-4">
      {products.map(product => (
        <ProductCard key={product.id} product={product} />
      ))}
    </div>
  );
}
